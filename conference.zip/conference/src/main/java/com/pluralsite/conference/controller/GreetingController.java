package com.pluralsite.conference.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class GreetingController {

	@GetMapping("/greeting")
	public ModelAndView greeting() {
		ModelAndView model = new ModelAndView();
		model.setViewName("greeting");
		return model;
	}
	
	@GetMapping("/login")
	public ModelAndView login() {
		ModelAndView model = new ModelAndView();
		model.setViewName("login");
		return model;
	}
//	
//	@PostMapping("/greeting")
//	public ModelAndView addgreeting() {
//		ModelAndView model = new ModelAndView();
//		model.setViewName("greeting");
//		return model;
//	}
	
	
}
