package com.irt.investmentrecommendation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

//@Configuration
public class InvestmentrecommendationConfig implements WebMvcConfigurer{
	
//	@Bean
//	public ViewResolver viewResolver() {
//		InternalResourceViewResolver bean = new InternalResourceViewResolver();
//		bean.setPrefix("/WEB-INF/jsp/");
//		bean.setSuffix(".jsp");
//		bean.setOrder(0);
//		return bean;
//	}
	
	
//	public void addViewControllers(ViewControllerRegistry registry) {
//		registry.addViewController("/home").setViewName("home");
//		//registry.addViewController("/").setViewName("home");
//		registry.addViewController("/questionnaire").setViewName("questionnaire");
//		registry.addViewController("/second").setViewName("second");
//		registry.addViewController("/third").setViewName("third");
//		registry.addViewController("/fourth").setViewName("fourth");
//		registry.addViewController("/fifth").setViewName("fifth");
//		registry.addViewController("/sixth").setViewName("sixth");
//		registry.addViewController("/result").setViewName("result");
//		registry.addViewController("/summary").setViewName("summary");
//		registry.addViewController("/login").setViewName("login"); 
//	}
}
