package com.irt.investmentrecommendation.model;

import javax.validation.constraints.NotNull;

public class WithdrawMoneyInYears {

	@NotNull
	public String option;
	public int score;
	
	
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
		setScore(option);
	}
	public int getScore() {
		return score;
	}
	public void setScore(String withdrawMoneyInYears) {
		if(withdrawMoneyInYears.equals("lessthan3")) {
			this.score = 3;
		}else if(withdrawMoneyInYears.equals("3to5")) {
			this.score = 6;
		}else if(withdrawMoneyInYears.equals("6to10")) {
			this.score = 8;
		}else if(withdrawMoneyInYears.equals("11ormore")) {
			this.score = 10;
		}else {
			this.score = 0;
		}
		
	}

}
