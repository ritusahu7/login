package com.irt.investmentrecommendation.model;

import javax.validation.constraints.NotNull;

public class AnualIncome {

	@NotNull
	private String option;
	private int score =0;
	
	
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
		setScore(option);
	}
	public int getScore() {
		return score;
	}
	public void setScore(String anualIncome) {
		if(anualIncome.equals("lessthan1lakh")) {
			this.score = 2;
		}else if(anualIncome.equals("1to5")) {
			this.score = 4;
		}else if(anualIncome.equals("5to10")) {
			this.score = 6;
		}else if(anualIncome.equals("10to30")) {
			this.score = 8;
		}else if(anualIncome.equals("greaterthan30")) {
			this.score = 10;
		}else {
			this.score = 0;
		}
		
		
	}

}
