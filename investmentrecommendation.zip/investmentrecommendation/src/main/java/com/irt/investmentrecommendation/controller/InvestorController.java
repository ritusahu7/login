package com.irt.investmentrecommendation.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.irt.investmentrecommendation.model.ActionOnStockChanges;
import com.irt.investmentrecommendation.model.Age;
import com.irt.investmentrecommendation.model.AnualIncome;
import com.irt.investmentrecommendation.model.Concern;
import com.irt.investmentrecommendation.model.InvestorDetail;
import com.irt.investmentrecommendation.model.RiskProfile;
import com.irt.investmentrecommendation.model.SpendingMoneyInYears;
import com.irt.investmentrecommendation.model.WithdrawMoneyInYears;
import com.irt.investmentrecommendation.service.InvestorService;

@Controller
public class InvestorController {

	@Autowired
	private InvestorDetail investor;
	
	@Autowired
	RiskProfile riskProfile;
	
	@Autowired
	private InvestorService investorService;
	
	@GetMapping("home")
	public String getUser(Model model) {
		investor = investorService.getInvestorDetail("John.doe@anymail.com");
		System.out.println("investor >> "+ investor.toString());
		model.addAttribute("investor", investor);
		return "home";
	}
	
	@GetMapping("/login")
	public ModelAndView getLogin(@RequestParam(value = "error",required = false) String error) {
		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject("error", "Invalid Credentials provided.");
		}

		model.setViewName("login");
		return model;
	}
	
	@GetMapping("questionnaire")
	public String getAge(@ModelAttribute ("age") Age age) {
		return "questionnaire";
	}
	
	@PostMapping("questionnaire")
	public String age(@Valid @ModelAttribute ("age") Age age, BindingResult result) {
		

		if(result.hasErrors()) {
			System.out.println("There were errors");
			return "questionnaire";
		}


		System.out.println( "age is "+ age.getOption() + ">>"+age.getScore());
		
		investor.setAge(age);
		return "redirect:second";
	}
	
	@GetMapping("second")
	public String income(@ModelAttribute ("anualIncome") AnualIncome anualIncome) {
		return "second";
	}
	
	@PostMapping("second")
	public String income(@Valid @ModelAttribute ("anualIncome") AnualIncome anualIncome,BindingResult result) {
		if(result.hasErrors()) {
			System.out.println("There were errors");
			return "second";
		}
		System.out.println( "Anual Income is "+ anualIncome.getOption()  + ">>"+anualIncome.getScore());
//		AnualIncome income = new AnualIncome();
//		income.setAnualIncome(values);
		investor.setAnulaIncome(anualIncome);
		return "redirect:third";
	}
	
	@GetMapping("third")
	public String withdraw(@ModelAttribute ("withdrawMoneyInYears") WithdrawMoneyInYears withdrawMoneyInYears) {
		return "third";
	}
	
	@PostMapping("third")
	public String withdraw(@Valid @ModelAttribute ("withdrawMoneyInYears") WithdrawMoneyInYears withdrawMoneyInYears,BindingResult result) {
		
//		if(result.hasErrors()) {
//			System.out.println("There were errors");
//			return "third";
//		}
		
		System.out.println( "Withdrawing money in years "+ withdrawMoneyInYears.getOption() + ">> "+withdrawMoneyInYears.getScore());
//		WithdrawMoneyInYears wmiy = new WithdrawMoneyInYears();
//		wmiy.setWithdrawMoneyInYears(values);
		investor.setWithdrawMoneyInYears(withdrawMoneyInYears);
		return "redirect:fourth";
	}
	
	@GetMapping("fourth")
	public String spending(@ModelAttribute ("spendingMoneyInYears") SpendingMoneyInYears spendingMoneyInYears) {
		return "fourth";
	}
	
	@PostMapping("fourth")
	public String spending(@Valid @ModelAttribute ("spendingMoneyInYears") SpendingMoneyInYears spendingMoneyInYears,BindingResult result) {
		
		if(result.hasErrors()) {
			System.out.println("There were errors");
			return "fourth";
		}
		
		System.out.println( "Spending money in years is "+ spendingMoneyInYears.getOption() + ">> "+spendingMoneyInYears.getScore());
//		SpendingMoneyInYears smiy = new SpendingMoneyInYears();
//		smiy.setSpendInYears(values);
		investor.setSpendingMoneyInYears(spendingMoneyInYears);
		return "redirect:fifth";
	}
	
	@GetMapping("fifth")
	public String concern(@ModelAttribute ("concern") Concern concern) {
		return "fifth";
	}
	
	@PostMapping("fifth")
	public String concern(@Valid @ModelAttribute ("concern") Concern concern,BindingResult result) {
		if(result.hasErrors()) {
			System.out.println("There were errors");
			return "fifth";
		}
		System.out.println( "Concern is "+ concern.getOption() +  ">> "+concern.getScore());
//		Concern concern = new Concern();
//		concern.setConcern(values);
		investor.setConcern(concern);
		return "redirect:sixth";
	}
	
	@GetMapping("sixth")
	public String toDo(@ModelAttribute ("actionOnStockChange") ActionOnStockChanges actionOnStockChange) {
		return "sixth";
	}
	
	@PostMapping("sixth")
	public String toDo(@Valid @ModelAttribute ("actionOnStockChange") ActionOnStockChanges actionOnStockChange,BindingResult result) {
		if(result.hasErrors()) {
			System.out.println("There were errors");
			return "sixth";
		}
		System.out.println( "Action is "+ actionOnStockChange.getOption() +  ">> "+actionOnStockChange.getScore());
//		ActionOnStockChanges aosc = new ActionOnStockChanges();
//		aosc.setAction(values);
		investor.setAction(actionOnStockChange);
		System.out.println(investor);
		return "redirect:result";
	}
	
	@GetMapping("result")
	public String getRistProfile(Model model) {
		riskProfile = investorService.getRiskProfile(investor);
		model.addAttribute("riskProfile", riskProfile);
		return "result";
	}
	
	@GetMapping("summary")
	public String getSummry(Model model) {
		riskProfile = investorService.getRiskProfile(investor);
		
		if(riskProfile.getScore()==0) {
			return "summarymessage";
		}
		
		
		model.addAttribute("riskProfile", riskProfile);
		return "summary";
		
	}
}
