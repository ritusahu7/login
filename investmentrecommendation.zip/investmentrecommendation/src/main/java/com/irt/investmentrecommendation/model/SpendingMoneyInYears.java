package com.irt.investmentrecommendation.model;

import javax.validation.constraints.NotNull;

public class SpendingMoneyInYears {

	@NotNull
	private String option;
	private int score;
	
	
	public String getOption() {
		return option;
	}



	public void setOption(String option) {
		this.option = option;
		setScore(option);
	}



	public int getScore() {
		return score;
	}
	
	
	
	public void setScore(String spendMoneyInYears) {
		if(spendMoneyInYears.equals("lessthan2")) {
			this.score = 3;
		}else if(spendMoneyInYears.equals("2to5")) {
			this.score = 6;
		}else if(spendMoneyInYears.equals("6to10")) {
			this.score = 8;
		}else if(spendMoneyInYears.equals("11ormore")) {
			this.score = 10;
		}else {
			this.score=0;
		}
		
		
	}

}
