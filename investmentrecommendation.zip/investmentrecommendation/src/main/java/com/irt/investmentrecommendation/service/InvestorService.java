package com.irt.investmentrecommendation.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.irt.investmentrecommendation.model.InvestorDetail;
import com.irt.investmentrecommendation.model.RiskProfile;

@Service
public class InvestorService {

	@Autowired
	RiskProfile riskProfile;
	
	List<InvestorDetail> investorDetails = new ArrayList<InvestorDetail>(
			Arrays.asList(new InvestorDetail("John Doe", "John.doe@anymail.com", "999-999-9999", "123 Main St. Anytown, India")));
	
	
	public InvestorDetail getInvestorDetail(String emailId) {
		System.out.println("email id is : "+ emailId);
		System.out.println(investorDetails.get(0).getName());
		return investorDetails.stream().filter(t-> t.getEmail().equals(emailId)).findFirst().get();
	}
	
	public RiskProfile getRiskProfile(InvestorDetail investor) {
		int score=0;
	
		if(investor.getAge()!=null || investor.getAnulaIncome()!=null||investor.getWithdrawMoneyInYears()!=null||investor.getSpendingMoneyInYears()!=null
				||investor.getConcern()!=null|| investor.getAction()!=null) {
		score = investor.getAge().getScore()
				+investor.getAnulaIncome().getScore()
				+investor.getWithdrawMoneyInYears().getScore()
				+investor.getSpendingMoneyInYears().getScore()
				+investor.getConcern().getScore()
				+investor.getAction().getScore();
		riskProfile.setScore(score);
		}else {
			riskProfile.setScore(0);
		}
		
		
		return riskProfile;
		
	}
}
